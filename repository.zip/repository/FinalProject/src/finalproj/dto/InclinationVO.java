package finalproj.dto;

public class InclinationVO {
	private int innum,snum;
	private String infile,ingrade;
	
	public int getInnum() {
		return innum;
	}
	public void setInnum(int innum) {
		this.innum = innum;
	}
	public int getSnum() {
		return snum;
	}
	public void setSnum(int snum) {
		this.snum = snum;
	}
	public String getInfile() {
		return infile;
	}
	public void setInfile(String infile) {
		this.infile = infile;
	}
	public String getIngrade() {
		return ingrade;
	}
	public void setIngrade(String ingrade) {
		this.ingrade = ingrade;
	}
	
}
