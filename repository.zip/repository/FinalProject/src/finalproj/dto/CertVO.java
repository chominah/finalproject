package finalproj.dto;

public class CertVO {
	private int crnum,cnt;
	private String crname;
	
	public int getCnt() {
		return cnt;
	}
	public void setCnt(int cnt) {
		this.cnt = cnt;
	}
	/**
	 * @return the crnum
	 */
	public int getCrnum() {
		return crnum;
	}
	/**
	 * @param crnum the crnum to set
	 */
	public void setCrnum(int crnum) {
		this.crnum = crnum;
	}
	/**
	 * @return the crname
	 */
	public String getCrname() {
		return crname;
	}
	/**
	 * @param crname the crname to set
	 */
	public void setCrname(String crname) {
		this.crname = crname;
	}
	
	
}
