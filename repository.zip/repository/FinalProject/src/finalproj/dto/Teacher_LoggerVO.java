package finalproj.dto;

public class Teacher_LoggerVO {
	private int logno;
	private String logdate;
	private int rnum;
	private int tnum;

	public int getLogno() {
		return logno;
	}

	public void setLogno(int logno) {
		this.logno = logno;
	}

	public String getLogdate() {
		return logdate;
	}

	public void setLogdate(String logdate) {
		this.logdate = logdate;
	}

	public int getRnum() {
		return rnum;
	}

	public void setRnum(int rnum) {
		this.rnum = rnum;
	}

	public int getTnum() {
		return tnum;
	}

	public void setTnum(int tnum) {
		this.tnum = tnum;
	}
}
