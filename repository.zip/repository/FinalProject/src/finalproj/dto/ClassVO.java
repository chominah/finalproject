package finalproj.dto;

public class ClassVO {
	private int cnum;
	private int cordinal;
	private int croom;
	private int totaldays,tnum;
	private String cname;
	private String cbegin;
	private String cend;
	
	public int getTnum() {
		return tnum;
	}
	public void setTnum(int tnum) {
		this.tnum = tnum;
	}
	public int getTotaldays() {
		return totaldays;
	}
	public void setTotaldays(int totaldays) {
		this.totaldays = totaldays;
	}
	/**
	 * @return the cnum
	 */
	public int getCnum() {
		return cnum;
	}
	/**
	 * @param cnum the cnum to set
	 */
	public void setCnum(int cnum) {
		this.cnum = cnum;
	}
	/**
	 * @return the cordinal
	 */
	public int getCordinal() {
		return cordinal;
	}
	/**
	 * @param cordinal the cordinal to set
	 */
	public void setCordinal(int cordinal) {
		this.cordinal = cordinal;
	}
	/**
	 * @return the croom
	 */
	public int getCroom() {
		return croom;
	}
	/**
	 * @param croom the croom to set
	 */
	public void setCroom(int croom) {
		this.croom = croom;
	}
	/**
	 * @return the cname
	 */
	public String getCname() {
		return cname;
	}
	/**
	 * @param cname the cname to set
	 */
	public void setCname(String cname) {
		this.cname = cname;
	}
	/**
	 * @return the cbegin
	 */
	public String getCbegin() {
		return cbegin;
	}
	/**
	 * @param cbegin the cbegin to set
	 */
	public void setCbegin(String cbegin) {
		this.cbegin = cbegin;
	}
	/**
	 * @return the cend
	 */
	public String getCend() {
		return cend;
	}
	/**
	 * @param cend the cend to set
	 */
	public void setCend(String cend) {
		this.cend = cend;
	}
	
	
}
