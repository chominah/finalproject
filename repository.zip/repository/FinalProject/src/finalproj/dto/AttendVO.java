package finalproj.dto;

public class AttendVO {
	private int snum;
	private String attdate;
	/**
	 * @return the snum
	 */
	public int getSnum() {
		return snum;
	}
	/**
	 * @param snum the snum to set
	 */
	public void setSnum(int snum) {
		this.snum = snum;
	}
	/**
	 * @return the attdate
	 */
	public String getAttdate() {
		return attdate;
	}
	/**
	 * @param attdate the attdate to set
	 */
	public void setAttdate(String attdate) {
		this.attdate = attdate;
	}
	
	
}
