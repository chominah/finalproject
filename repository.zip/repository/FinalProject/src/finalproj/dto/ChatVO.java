package finalproj.dto;

public class ChatVO {
	private int chnum;
	private int groupno;
	private String chfile;
	private String chdate;
	/**
	 * @return the chnum
	 */
	public int getChnum() {
		return chnum;
	}
	/**
	 * @param chnum the chnum to set
	 */
	public void setChnum(int chnum) {
		this.chnum = chnum;
	}
	/**
	 * @return the groupno
	 */
	public int getGroupno() {
		return groupno;
	}
	/**
	 * @param groupno the groupno to set
	 */
	public void setGroupno(int groupno) {
		this.groupno = groupno;
	}
	/**
	 * @return the chfile
	 */
	public String getChfile() {
		return chfile;
	}
	/**
	 * @param chfile the chfile to set
	 */
	public void setChfile(String chfile) {
		this.chfile = chfile;
	}
	/**
	 * @return the chdate
	 */
	public String getChdate() {
		return chdate;
	}
	/**
	 * @param chdate the chdate to set
	 */
	public void setChdate(String chdate) {
		this.chdate = chdate;
	}
	
	
	
	
	
}
