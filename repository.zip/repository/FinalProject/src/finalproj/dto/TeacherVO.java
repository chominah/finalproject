package finalproj.dto;

public class TeacherVO {
	private int tnum;
	private String tname;
	private String tbirth;
	private String tmail;
	private String taddr;
	private String tphone;
	private int rolnum;
	private String tgender;
	private String tid, tpwd;	
	private TboardVO tboard;
	

	public TboardVO getTboard() {
		return tboard;
	}

	public void setTboard(TboardVO tboard) {
		this.tboard = tboard;
	}

	public int getRolnum() {
		return rolnum;
	}

	public void setRolnum(int rolnum) {
		this.rolnum = rolnum;
	}

	public int getTnum() {
		return tnum;
	}

	public void setTnum(int tnum) {
		this.tnum = tnum;
	}

	public String getTname() {
		return tname;
	}

	public void setTname(String tname) {
		this.tname = tname;
	}

	public String getTbirth() {
		return tbirth;
	}

	public void setTbirth(String tbirth) {
		this.tbirth = tbirth;
	}

	public String getTmail() {
		return tmail;
	}

	public void setTmail(String tmail) {
		this.tmail = tmail;
	}

	public String getTaddr() {
		return taddr;
	}

	public void setTaddr(String taddr) {
		this.taddr = taddr;
	}

	public String getTphone() {
		return tphone;
	}

	public void setTphone(String tphone) {
		this.tphone = tphone;
	}

	public String getTgender() {
		return tgender;
	}

	public void setTgender(String tgender) {
		this.tgender = tgender;
	}

	public String getTid() {
		return tid;
	}

	public void setTid(String tid) {
		this.tid = tid;
	}

	public String getTpwd() {
		return tpwd;
	}

	public void setTpwd(String tpwd) {
		this.tpwd = tpwd;
	}


}
