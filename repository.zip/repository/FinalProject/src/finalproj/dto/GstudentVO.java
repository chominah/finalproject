package finalproj.dto;

public class GstudentVO {
	private int gsnum;
	private int gsordinal;
	private int crnum;
	private String gsmajor;
	/**
	 * @return the gsnum
	 */
	public int getGsnum() {
		return gsnum;
	}
	/**
	 * @param gsnum the gsnum to set
	 */
	public void setGsnum(int gsnum) {
		this.gsnum = gsnum;
	}
	/**
	 * @return the gsordinal
	 */
	public int getGsordinal() {
		return gsordinal;
	}
	/**
	 * @param gsordinal the gsordinal to set
	 */
	public void setGsordinal(int gsordinal) {
		this.gsordinal = gsordinal;
	}
	/**
	 * @return the crnum
	 */
	public int getCrnum() {
		return crnum;
	}
	/**
	 * @param crnum the crnum to set
	 */
	public void setCrnum(int crnum) {
		this.crnum = crnum;
	}
	/**
	 * @return the gsmajor
	 */
	public String getGsmajor() {
		return gsmajor;
	}
	/**
	 * @param gsmajor the gsmajor to set
	 */
	public void setGsmajor(String gsmajor) {
		this.gsmajor = gsmajor;
	}
	
	
}
