package finalproj.dto;

public class Admin_LoggerVO {
	private int logno;
	private int rnum;
	private int adnum;
	private String logdate;
	/**
	 * @return the logno
	 */
	public int getLogno() {
		return logno;
	}
	/**
	 * @param logno the logno to set
	 */
	public void setLogno(int logno) {
		this.logno = logno;
	}
	/**
	 * @return the rnum
	 */
	public int getRnum() {
		return rnum;
	}
	/**
	 * @param rnum the rnum to set
	 */
	public void setRnum(int rnum) {
		this.rnum = rnum;
	}
	/**
	 * @return the adnum
	 */
	public int getAdnum() {
		return adnum;
	}
	/**
	 * @param adnum the adnum to set
	 */
	public void setAdnum(int adnum) {
		this.adnum = adnum;
	}
	/**
	 * @return the logdate
	 */
	public String getLogdate() {
		return logdate;
	}
	/**
	 * @param logdate the logdate to set
	 */
	public void setLogdate(String logdate) {
		this.logdate = logdate;
	}
	
	
	
}
