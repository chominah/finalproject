package finalproj.dto;

public class AdminVO {
	private int adnum,rolnum;
	private String adname;
	private String adbirth;
	private String admail;
	private String adaddr;
	private String adphone;
	private String adgender;
	private String adid;
	private String adpwd;
	
	public int getRolnum() {
		return rolnum;
	}
	public void setRolnum(int rolnum) {
		this.rolnum = rolnum;
	}
	/**
	 * @return the adnum
	 */
	public int getAdnum() {
		return adnum;
	}
	/**
	 * @param adnum the adnum to set
	 */
	public void setAdnum(int adnum) {
		this.adnum = adnum;
	}
	/**
	 * @return the adname
	 */
	public String getAdname() {
		return adname;
	}
	/**
	 * @param adname the adname to set
	 */
	public void setAdname(String adname) {
		this.adname = adname;
	}
	/**
	 * @return the adbirth
	 */
	public String getAdbirth() {
		return adbirth;
	}
	/**
	 * @param adbirth the adbirth to set
	 */
	public void setAdbirth(String adbirth) {
		this.adbirth = adbirth;
	}
	/**
	 * @return the admail
	 */
	public String getAdmail() {
		return admail;
	}
	/**
	 * @param admail the admail to set
	 */
	public void setAdmail(String admail) {
		this.admail = admail;
	}
	/**
	 * @return the adaddr
	 */
	public String getAdaddr() {
		return adaddr;
	}
	/**
	 * @param adaddr the adaddr to set
	 */
	public void setAdaddr(String adaddr) {
		this.adaddr = adaddr;
	}
	/**
	 * @return the adphone
	 */
	public String getAdphone() {
		return adphone;
	}
	/**
	 * @param adphone the adphone to set
	 */
	public void setAdphone(String adphone) {
		this.adphone = adphone;
	}
	/**
	 * @return the adgender
	 */
	public String getAdgender() {
		return adgender;
	}
	/**
	 * @param adgender the adgender to set
	 */
	public void setAdgender(String adgender) {
		this.adgender = adgender;
	}
	/**
	 * @return the adid
	 */
	public String getAdid() {
		return adid;
	}
	/**
	 * @param adid the adid to set
	 */
	public void setAdid(String adid) {
		this.adid = adid;
	}
	/**
	 * @return the adpwd
	 */
	public String getAdpwd() {
		return adpwd;
	}
	/**
	 * @param adpwd the adpwd to set
	 */
	public void setAdpwd(String adpwd) {
		this.adpwd = adpwd;
	}
	
	
}
