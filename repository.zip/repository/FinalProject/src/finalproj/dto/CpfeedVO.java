package finalproj.dto;

public class CpfeedVO {
	private int cpfnum;
	private int snum;
	private String cpfcontent;
	private String cpfdate;
	private String cpnum,cpfmemo,cpffile;
	
	public String getCpfmemo() {
		return cpfmemo;
	}
	public void setCpfmemo(String cpfmemo) {
		this.cpfmemo = cpfmemo;
	}
	public String getCpffile() {
		return cpffile;
	}
	public void setCpffile(String cpffile) {
		this.cpffile = cpffile;
	}
	/**
	 * @return the cpfnum
	 */
	public int getCpfnum() {
		return cpfnum;
	}
	/**
	 * @param cpfnum the cpfnum to set
	 */
	public void setCpfnum(int cpfnum) {
		this.cpfnum = cpfnum;
	}
	/**
	 * @return the snum
	 */
	public int getSnum() {
		return snum;
	}
	/**
	 * @param snum the snum to set
	 */
	public void setSnum(int snum) {
		this.snum = snum;
	}
	/**
	 * @return the cpfcontent
	 */
	public String getCpfcontent() {
		return cpfcontent;
	}
	/**
	 * @param cpfcontent the cpfcontent to set
	 */
	public void setCpfcontent(String cpfcontent) {
		this.cpfcontent = cpfcontent;
	}
	/**
	 * @return the cpfdate
	 */
	public String getCpfdate() {
		return cpfdate;
	}
	/**
	 * @param cpfdate the cpfdate to set
	 */
	public void setCpfdate(String cpfdate) {
		this.cpfdate = cpfdate;
	}
	/**
	 * @return the cpnum
	 */
	public String getCpnum() {
		return cpnum;
	}
	/**
	 * @param cpnum the cpnum to set
	 */
	public void setCpnum(String cpnum) {
		this.cpnum = cpnum;
	}
	
	
}
