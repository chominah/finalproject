package finalproj.dto;

public class ScheduleVO {
	private String shdate,shname,shloc;
	private int cnum;

	public String getShdate() {
		return shdate;
	}

	public void setShdate(String shdate) {
		this.shdate = shdate;
	}

	public String getShname() {
		return shname;
	}

	public void setShname(String shname) {
		this.shname = shname;
	}

	public String getShloc() {
		return shloc;
	}

	public void setShloc(String shloc) {
		this.shloc = shloc;
	}

	public int getCnum() {
		return cnum;
	}

	public void setCnum(int cnum) {
		this.cnum = cnum;
	}
}
