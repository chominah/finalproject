package finalproj.dto;

public class JobkeywordVO {
	private int keynum;
	private String keyword;
	/**
	 * @return the keynum
	 */
	public int getKeynum() {
		return keynum;
	}
	/**
	 * @param keynum the keynum to set
	 */
	public void setKeynum(int keynum) {
		this.keynum = keynum;
	}
	/**
	 * @return the keyword
	 */
	public String getKeyword() {
		return keyword;
	}
	/**
	 * @param keyword the keyword to set
	 */
	public void setKeyword(String keyword) {
		this.keyword = keyword;
	}
	
	
}
