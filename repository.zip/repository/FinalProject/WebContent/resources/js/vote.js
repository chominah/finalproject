/**
 * resources/js/vote.js
 */
function resFunn(num){
	//alert(num);
	//설문 결과를 출력하기 위한 요청으로 primary key를 보낸다.
	location="voteres?num="+num;
}