/**
 * js/basic.js
 */
function test(){
	alert("Test!");
}